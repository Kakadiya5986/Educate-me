import "./Footer.css";

const Footer=()=>{

return (
    <footer className="py-4 bg-light footercss" sticky="bottom">
    <div className="container text-center ">
      <small>Copyright &copy; UnitedTutoring</small>
     
    </div>
  </footer>
);


}

export default Footer;