const Dashboard=()=>{
    return (
        <h1>User logged in succesfully</h1>
    );
};

export default Dashboard;