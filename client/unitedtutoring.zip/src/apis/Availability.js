export const SAVE_AVAILABILITY = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/save-availability';
export const GET_AVAILABILITY = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/get-availability';
export const SAVE_SLOT_BOOKING = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/saveslot-booking';
export const GET_BOOKING_SLOT_PENDING_STATUS = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/getbookingslotinpending';

