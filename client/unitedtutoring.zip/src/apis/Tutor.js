export const GET_TUTOR_DETAILS = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/get-user-details';
export const GET_TUTOR_BOOKINGS = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/dev/get-tutor-bookings';
export const UPDATE_BOOKING = 'https://ks727y03s0.execute-api.eu-north-1.amazonaws.com/updaterequest'